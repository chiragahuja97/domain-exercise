package com.example.swipemicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwipeMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwipeMicroserviceApplication.class, args);
	}

}

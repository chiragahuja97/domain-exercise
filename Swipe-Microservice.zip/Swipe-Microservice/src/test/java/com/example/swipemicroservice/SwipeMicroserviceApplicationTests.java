package com.example.swipemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwipeMicroserviceApplicationTests {

	@Test
	void contextLoads() {

	}

}
